
{
    'name': "POS Multi Currency",
    'summary': """
        Support multi currency payment in pos
    """,
    'description': """
        Support multi currency payment in pos
    """,
    'author': "RDFlex",
    'company': 'RDFlex',
    'maintainer': 'RDFlex',
    'website': "https://rdflex.com",
    'category': 'Point of sale',
    'version': "16.0.1.0.0",
    'license': 'OPL-1',
    'depends': ['point_of_sale'],
    'images': ['static/description/banner.jpg'],
    'data': [
        'views/pos_multi_currency.xml',
    ],

    'assets': {
        'point_of_sale.assets': [
            'rdflex_pos_multi_currency/static/src/js/*',
            'rdflex_pos_multi_currency/static/src/css/*',
            'rdflex_pos_multi_currency/static/src/xml/*',
        ],
}
